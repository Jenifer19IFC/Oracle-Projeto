import mysql.connector

class GerenciadorBancoDados:
    def __init__(self, user, password, host):
        self.config = {
            'user': user,
            'password': password,
            'host': host,
        }
        self.connection = None
        self.cursor = None

    def conectar(self):
        try:
            self.connection = mysql.connector.connect(**self.config)

            if self.connection.is_connected():
                print('Conexão estabelecida com sucesso!')
                self.cursor = self.connection.cursor()

        except mysql.connector.Error as error:
            print('Erro ao conectar ao banco de dados: {}'.format(error))

    def desconectar(self):
        if self.cursor:
            self.cursor.close()
        if self.connection and self.connection.is_connected():
            self.connection.close()
            print('Conexão fechada.')

    def criar_banco_dados(self, nome_database):
        try:
            self.cursor.execute(f"CREATE DATABASE IF NOT EXISTS {nome_database}")
            print(f'Banco de dados "{nome_database}" criado com sucesso!')

        except mysql.connector.Error as error:
            print('Erro ao criar o banco de dados: {}'.format(error))

    def selecionar_banco_dados(self, nome_database):
        try:
            self.cursor.execute(f"USE {nome_database}")
            print(f'Banco de dados "{nome_database}" selecionado!')

        except mysql.connector.Error as error:
            print('Erro ao selecionar o banco de dados: {}'.format(error))

    def criar_tabela_funcionarios(self):
        try:
            create_table_query = '''
            CREATE TABLE IF NOT EXISTS funcionarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100),
                endereco VARCHAR(100)
            )
            '''
            self.cursor.execute(create_table_query)
            print('Tabela de funcionários criada com sucesso!')

        except mysql.connector.Error as error:
            print('Erro ao criar a tabela de funcionários: {}'.format(error))

    def inserir_funcionarios(self, funcionarios):
        try:
            insert_query = '''
            INSERT INTO funcionarios (nome, endereco) VALUES (%s, %s)
            '''
            self.cursor.executemany(insert_query, funcionarios)
            self.connection.commit()
            print('Inserção de funcionários concluída.')

        except mysql.connector.Error as error:
            print('Erro ao inserir funcionários: {}'.format(error))

    def listar_funcionarios(self):
        try:
            select_query = '''
            SELECT * FROM funcionarios
            '''
            self.cursor.execute(select_query)

            print('\nLista de funcionários:')
            for funcionario in self.cursor.fetchall():
                print(funcionario)

        except mysql.connector.Error as error:
            print('Erro ao listar funcionários: {}'.format(error))


# Exemplo de utilização da classe GerenciadorBancoDados
gerenciador = GerenciadorBancoDados('admin', 'senha_aqui', 'localhost')
gerenciador.conectar()
gerenciador.criar_banco_dados('fun')
gerenciador.selecionar_banco_dados('fun')
gerenciador.criar_tabela_funcionarios()

# Inserindo funcionários
funcionarios = [
    ('Flávia', 'Rio do Sul'),
    ('Marcos Silva', 'Ituporanga'),
    ('Karla Ramos', 'Imbuia')
]
gerenciador.inserir_funcionarios(funcionarios)

# Listando os funcionários
gerenciador.listar_funcionarios()

gerenciador.desconectar()
